 $(document).ready(function(){
   // Do stuff onload
 });